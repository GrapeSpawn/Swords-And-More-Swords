//
//  BattleViewController.m
//  Project
//
//  Created by sebastion andrus on 11/8/12.
//  Copyright (c) 2012 sebastion andrus. All rights reserved.
//

#import "BattleViewController.h"


@interface BattleViewController (){
    bool *usersTurn;
    NSInteger hold;
    NSArray *display;
    bool *selection;
    Abilitees *cast;
    PlayerData *caster;
    PlayerData *defending;
    bool *attacking;
    NSMutableArray *turns;
    int totalturns;
    int userDeathCount;
    int mobDeathCount;
    int nxtPerson;

}

@end

@implementation BattleViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    self.battleText.text = @"THE BATLE HAS STARTED!!";
    NSDate *randseed = [[NSDate alloc] init];
    randseed = [randseed dateByAddingTimeInterval:0];
    srand(randseed.timeIntervalSince1970);
    selection = NO;
    attacking = NO;
    display = NULL;
    totalturns = 0;
    userDeathCount = 0;
    mobDeathCount = 0;
    nxtPerson = 0;
    PlayerData *holdTemp;
    for(int i = 0; i < self.Users.count; i++){
        holdTemp = (PlayerData *)[self.Users objectAtIndex:i];
        totalturns = totalturns + holdTemp.Agillity.intValue;
        
    }
    for (int i = 0; i<self.Mobs.count; i++) {
        holdTemp = (PlayerData *)[self.Mobs objectAtIndex:i];
        //NSLog(holdTemp.Name);
        totalturns = totalturns + holdTemp.Agillity.intValue;
    }
    self.MainPlayerPort.image = ((PlayerData *)[self.Users objectAtIndex:0]).Port;
    self.PartyTwoPort.image = ((PlayerData *)[self.Users objectAtIndex:0]).Port;
    self.PartyOnePort.image = ((PlayerData *)[self.Users objectAtIndex:0]).Port;

    self.FirstEnamyPort.image = ((PlayerData *)[self.Mobs objectAtIndex:0]).Port;
    self.SecondEnemyPort.image = ((PlayerData *)[self.Mobs objectAtIndex:0]).Port;
    self.ThirdEnamyPort.image = ((PlayerData *)[self.Mobs objectAtIndex:0]).Port;
    self.FithEnemyPort.image = ((PlayerData *)[self.Mobs objectAtIndex:0]).Port;
    self.FourthEnemyPort.image = ((PlayerData *)[self.Mobs objectAtIndex:0]).Port;
    self.SixthEnemyPort.image = ((PlayerData *)[self.Mobs objectAtIndex:0]).Port;
    
    [self setTurns];
    [self turn];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidAppear:(BOOL)animated{
    if(self.EndGame)
        [self.delegate BattleViewControllerDidFinish:self];
    [super viewDidAppear:YES];
}

#pragma mark - Turn Set

-(void)setTurns{
    turns = [[NSMutableArray alloc] init];
    NSMutableArray *rtn = [[NSMutableArray alloc] init];
    int j = 0;
    int k = 0;
    for (int i = 0; i<self.Users.count; i++) {
        j =((PlayerData *)[self.Users objectAtIndex:i]).Agillity.intValue + j;
        while(k<j){
            [turns addObject:[self.Users objectAtIndex:i]];
            k++;
        }
    }
    for (int i = 0; i<self.Mobs.count; i++) {
        j =((PlayerData *)[self.Mobs objectAtIndex:i]).Agillity.intValue + j;
        while(k<j){
            [turns addObject:[self.Mobs objectAtIndex:i]];
            k++;            
        }
    }
    while(turns.count>0 && !(rtn.count == (self.Users.count + self.Mobs.count))){
		int choice = rand() % totalturns;
        
		if(![rtn containsObject:[turns objectAtIndex:choice]]){
			[rtn addObject:[turns objectAtIndex:choice]];
			[turns removeObjectAtIndex:choice];
			totalturns--;
		}
	}
    
	turns = rtn;
}

-(void)turn{
    
    if ((self.Users.count <= userDeathCount)) {
        [self End];
    }
    else if((self.Mobs.count <= mobDeathCount)){
        [self End];
    }
    else{
        //NSLog(@"%d",mobDeathCount);
        nxtPerson++;
		if(nxtPerson>=turns.count)
			nxtPerson = 0;
        caster = (PlayerData *)[turns objectAtIndex:nxtPerson];
        if(caster.isDead)
            [self turn];
        bool rtn = caster.isUser;
        [caster statusChck];
        
        self.table.hidden = !rtn;
        self.attckbuttn.hidden = !rtn;
        self.skllButten.hidden = !rtn;
        self.itemButten.hidden = !rtn;
        self.HP.text = caster.CurrentHp.description;
        self.MP.hidden = !rtn;
        self.MPLabel.hidden = !rtn;
    
        self.proceedButten.hidden = rtn;
        
        selection = NO;
        attacking = NO;
        usersTurn = &rtn;
        display = nil;
        if(rtn){
            self.whoseTurn.text = @"Your Turn:";
            self.MP.text = caster.CurrentMp.description;
        }
        else{
            self.whoseTurn.text = @"Enemy's Turn:";
        }
        [self.table reloadData];
    }
}

-(void)healthTest{
    if(defending.CurrentHp.intValue < 1){
        defending.isDead = YES;
        if (defending.isUser) {
            userDeathCount++;
        }
        else
            mobDeathCount++;
    }
    if(caster.CurrentHp.intValue < 1){
        caster.isDead = YES;
        if (defending.isUser) {
            userDeathCount++;
        }
        else
            mobDeathCount++;
        [self turn];
    }
}

#pragma mark - Buttons

- (IBAction)Proceed:(id)sender {
    defending = (PlayerData *)[self.Users objectAtIndex:(rand() % self.Users.count)];
    self.battleText.text =[self PlayerAttack];
    [self turn];
}

- (IBAction)Attack:(id)sender {
    display = self.Mobs;
    attacking = YES;
    [self.table reloadData];
}

- (IBAction)Skill:(id)sender {
    display = caster.Skills;
    selection = NO;
    attacking = NO;
    [self.table reloadData];
}

- (IBAction)Item:(id)sender {
    display = caster.Items;
    selection = NO;
    attacking = NO;
    [self.table reloadData];
}

#pragma mark - Table

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return display.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    if(attacking || selection){
        PlayerData *temp = [[PlayerData alloc] init];
        temp = (PlayerData *)[display objectAtIndex:indexPath.row];
        cell.textLabel.text = temp.Name;
        if (temp.isDead) {
            cell.detailTextLabel.text = @"KO";
        }
        else
            cell.detailTextLabel.text = [[NSString alloc] initWithFormat:@"%i", temp.CurrentHp.intValue];
    }
    else{
        Abilitees *temp =[[Abilitees alloc] init];
        temp = (Abilitees *)[display objectAtIndex:indexPath.row];
        cell.textLabel.text = temp.Name;
        cell.detailTextLabel.text = [[NSString alloc] initWithFormat:@"%i", temp.CountCost.intValue];
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if(usersTurn){
        if(attacking){
            defending = (PlayerData *)[display objectAtIndex:indexPath.row];
            self.battleText.text = [self PlayerAttack];
            [self healthTest];
            [self turn];
        }
        else if(selection){
            defending = (PlayerData *)[display objectAtIndex:indexPath.row];
            self.battleText.text = [cast EffectAttker:caster Deffender:defending];
            [self healthTest];
            [self turn];
        }
        else{
            cast = (Abilitees *)[display objectAtIndex:indexPath.row];
            if (cast.Friendly) {
                display = self.Users;
            }
            else{
                display = self.Mobs;
            }
            selection = YES;
            [self.table reloadData];
        }
        
    }
    
}

#pragma mark - behind scene

-(NSString *)PlayerAttack{
    NSString *rtn = [[NSString alloc] init];
    int  DAM = 0;
    DAM = DAM + caster.AttackPower.intValue - (rand()%defending.AttackPower.intValue);
    if(DAM<1)
        DAM=1;
    defending.CurrentHp = [NSNumber numberWithInt:(defending.CurrentHp.intValue - DAM)];
    rtn = [NSString stringWithFormat:@"%@ dealt %i to %@", caster.Name, DAM, defending.Name];
    [self healthTest];
    return rtn;
}

- (void)End
{
    NSLog(@"END");
    if (self.Users.count == 0)
    {
        NSData *user = [NSKeyedArchiver archivedDataWithRootObject:self.Users];
        [[NSUserDefaults standardUserDefaults] setObject:user forKey:@"User"];
    }
        
    
    self.EndGame = YES;
    [self.delegate BattleViewControllerDidFinish:self];
}
@end
