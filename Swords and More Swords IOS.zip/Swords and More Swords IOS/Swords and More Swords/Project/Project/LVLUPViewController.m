//
//  LVLUPViewController.m
//  Swords and More Swords
//
//  Created by sebastion andrus on 3/23/13.
//  Copyright (c) 2013 3400 mac. All rights reserved.
//

#import "LVLUPViewController.h"
#import "LvlCellViewController.h"

@interface LVLUPViewController ()
@property (strong,nonatomic)NSNumber *statPoint;
@end

@implementation LVLUPViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    self.statPoint = [NSNumber numberWithInt:(3+(self.player.Intelligance.intValue/4))];
    self.StatPoints.text = self.statPoint.description;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 4;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    LvlCellViewController *cell = [tableView dequeueReusableCellWithIdentifier:@"StatCell" forIndexPath:indexPath];
    if (indexPath.row==0) {
        cell.StatName.text = @"Strength";
        cell.StatValue.text = self.player.AttackPower.description;
    }
    else if (indexPath.row==1) {
        cell.StatName.text = @"Agility";
        cell.StatValue.text = self.player.Agillity.description;
    }
    else if (indexPath.row==2) {
        cell.StatName.text = @"Intelligance";
        cell.StatValue.text = self.player.Intelligance.description;
    }
    else{
        cell.StatName.text = @"Max Health";
        cell.StatValue.text = self.player.MaxHp.description;
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row==0) {
        self.player.AttackPower= [NSNumber numberWithInt:(self.player.AttackPower.intValue +1)];
    }
    else if (indexPath.row==1) {
        self.player.Agillity = [NSNumber numberWithInt:(self.player.AttackPower.intValue +1)];
    }
    else if (indexPath.row==2) {
        self.player.Intelligance = [NSNumber numberWithInt:(self.player.AttackPower.intValue +1)];
    }
    else{
        self.player.MaxHp = [NSNumber numberWithInt:(self.player.AttackPower.intValue +1)];
    }
    self.statPoint = [NSNumber numberWithInt:(self.statPoint.intValue-1)];
    self.StatPoints.text = self.statPoint.description;
    [self.Table reloadData];
}

@end
