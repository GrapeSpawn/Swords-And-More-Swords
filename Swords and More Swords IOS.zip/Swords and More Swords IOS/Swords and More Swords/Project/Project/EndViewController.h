//
//  EndViewController.h
//  Project
//
//  Created by sebastion andrus on 11/8/12.
//  Copyright (c) 2012 sebastion andrus. All rights reserved.
//

#import <UIKit/UIKit.h>

@class EndViewController;

@protocol EndViewControllerDelegate
- (void)EndViewControllerDidFinish:(EndViewController *)controller;
@end

@interface EndViewController : UIViewController

@property (weak, nonatomic) id <EndViewControllerDelegate> delegate;

- (IBAction)EndE:(id)sender;

- (IBAction)EndP:(id)sender;

@end
