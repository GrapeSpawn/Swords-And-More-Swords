//
//  PlayerData.h
//  Project
//
//  Created by sebastion andrus on 11/15/12.
//  Copyright (c) 2012 sebastion andrus. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface PlayerData : NSObject <NSCoding>

@property (strong, nonatomic) NSNumber *Agillity;

@property (strong, nonatomic) NSNumber *AttackPower;

@property (strong, nonatomic) NSNumber *MaxHp;

@property (strong, nonatomic) NSNumber *MaxMp;

@property (strong, nonatomic) NSNumber *Level;

@property (strong, nonatomic) NSString *Name;

@property (strong, nonatomic) NSNumber *Intelligance;

@property (strong, nonatomic) NSNumber *Exp;

@property (strong, nonatomic) NSNumber *NxtLvlExp;

@property (strong, nonatomic) NSNumber *CurrentHp;

@property (strong, nonatomic) NSNumber *CurrentMp;

@property (strong, nonatomic) NSMutableArray *Skills;

@property (strong, nonatomic) NSMutableArray *Items;

@property (strong, nonatomic) NSNumber *poisonCounter;

@property (strong, nonatomic) UIImage *Port;

@property (assign) bool isUser;

@property (assign) bool isDead;

@property (assign) bool revivable;

@property (assign) bool didLvl;

-(void) statusChck;

-(void) LevlUp;

- (id)initWithLvl:(int)Lvl;

@end
