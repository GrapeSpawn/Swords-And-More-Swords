//
//  PlayerData.m
//  Project
//
//  Created by sebastion andrus on 11/15/12.
//  Copyright (c) 2012 sebastion andrus. All rights reserved.
//

#import "PlayerData.h"
#import "Items.h"
#import "Skills.h"
#import "Potion.h"
#import "Skills.h"
#import "Fire.h"
#import "Either.h"
#import "Posion.h"

@implementation PlayerData

- (void) encodeWithCoder:(NSCoder *)aCoder{
    [aCoder encodeObject:self.Name forKey:@"Name"];
    [aCoder encodeObject:self.CurrentHp forKey:@"CurrentHP"];
    [aCoder encodeObject:self.CurrentMp forKey:@"CurrentMp"];
    [aCoder encodeObject:self.MaxHp forKey:@"MaxHp"];
    [aCoder encodeObject:self.MaxMp forKey:@"MaxMp"];
    [aCoder encodeObject:self.AttackPower forKey:@"Attack"];
    [aCoder encodeObject:self.Skills forKey:@"Skills"];
    [aCoder encodeObject:self.Items forKey:@"Items"];
    [aCoder encodeObject:self.Agillity forKey:@"Agillity"];
    [aCoder encodeObject:self.Level forKey:@"Level"];
    [aCoder encodeBool:self.isUser forKey:@"isUser"];
    [aCoder encodeBool:self.isDead forKey:@"isDead"];
    [aCoder encodeObject:self.Port forKey:@"Port"];
    [aCoder encodeObject:self.Intelligance forKey:@"Intelligance"];
    
}

- (id)initWithCoder:(NSCoder *)aDecoder{
    self = [super init];
    
    if(self){
        self.Name = [aDecoder decodeObjectForKey:@"Name"];
        self.CurrentHp = [aDecoder decodeObjectForKey:@"CurrentHP"];
        self.CurrentMp = [aDecoder decodeObjectForKey:@"CurrentMp"];
        self.MaxHp = [aDecoder decodeObjectForKey:@"MaxHp"];
        self.MaxMp = [aDecoder decodeObjectForKey:@"MaxMp"];
        self.AttackPower = [aDecoder decodeObjectForKey:@"Attack"];
        self.Skills = [aDecoder decodeObjectForKey:@"Skills"];
        self.Items = [aDecoder decodeObjectForKey:@"Items"];
        self.Agillity =[aDecoder decodeObjectForKey:@"Agillity"];
        self.Level = [aDecoder decodeObjectForKey:@"Level"];
        self.isDead = [aDecoder decodeBoolForKey:@"isDead"];
        self.isUser = [aDecoder decodeBoolForKey:@"isUser"];
        self.Port = [aDecoder decodeObjectForKey:@"Port"];
        _Intelligance = [aDecoder decodeObjectForKey:@"Intelligance"];
        _poisonCounter = [NSNumber numberWithInt:0];
    }
    return self;
    
}

- (void) statusChck{
    if(self.poisonCounter.intValue > 0){
        self.poisonCounter = [NSNumber numberWithInt:(self.poisonCounter.intValue -1)];
        [self poison];
    }
}

-(void) poison{
    self.CurrentHp = [NSNumber numberWithInt:(self.CurrentHp.intValue - 2)];
}

-(void)LevlUp{
    if(self.Exp.intValue >= self.NxtLvlExp.intValue){
        self.didLvl = YES;
        self.Level = [NSNumber numberWithInt:(self.Level.intValue+1)];
        self.Exp =[NSNumber numberWithInt:(0)];
        self.NxtLvlExp = [NSNumber numberWithInt:(self.NxtLvlExp.intValue*1.3)];
    }
    NSLog(@"HI");
}

- (id)init {
    self = [super init];
    if (self) {
        _Level = [NSNumber numberWithInt:1];
        _Items = [[NSMutableArray alloc] init];
        _Skills = [[NSMutableArray alloc] init];
        _isDead = NO;
        Items *Itemp = [[Potion alloc] init];
        Itemp.CountCost = [[NSNumber alloc] initWithInt:4];
        Skills *Stemp = [[Fire alloc] init];
        
        [_Skills addObject:Stemp];
        [_Items addObject:Itemp];
        
        Stemp = [[Posion alloc] init];
        [_Skills addObject:Stemp];
        Itemp = [[Either alloc] init];
        Itemp.CountCost = [NSNumber numberWithInt:3];
        //NSLog(@"%d",Itemp.CountCost.intValue);
        [_Items addObject:Itemp];
        _Name = @"user";
        _MaxHp =[NSNumber numberWithInt:100];
        _CurrentHp =[NSNumber numberWithInt:100];
        _MaxMp =[NSNumber numberWithInt:50];
        _CurrentMp =[NSNumber numberWithInt:50];
        _Agillity = [NSNumber numberWithInt:3];
        _isUser = YES;
        _AttackPower = [NSNumber numberWithInt:5];
        _Port = [UIImage imageNamed:@"PlayerSAMS"];
        _poisonCounter = [NSNumber numberWithInt:0];
        _Intelligance = [NSNumber numberWithInt:4];
        _Exp = [NSNumber numberWithInt:0];
        _NxtLvlExp = [NSNumber numberWithInt:50];
    }
    return self;
}

- (id)initWithLvl:(int)Lvl {
    self = [super init];
    if (self) {
        _Level = [NSNumber numberWithInt:Lvl];
        _Items = [[NSMutableArray alloc] init];
        _Skills = [[NSMutableArray alloc] init];
        _isDead = NO;
        Items *Itemp = [[Potion alloc] init];
        Itemp.CountCost = [[NSNumber alloc] initWithInt:4];
        Skills *Stemp = [[Fire alloc] init];
        _poisonCounter = [NSNumber numberWithInt:0];
        [_Skills addObject:Stemp];
        [_Items addObject:Itemp];
        _Exp = [NSNumber numberWithInt:20];
        Stemp = [[Posion alloc] init];
        [_Skills addObject:Stemp];
        Itemp = [[Either alloc] init];
        Itemp.CountCost = [NSNumber numberWithInt:3];
        //NSLog(@"%d",Itemp.CountCost.intValue);
        [_Items addObject:Itemp];
        _Name = @"user";
        _MaxHp =[NSNumber numberWithInt:100];
        _CurrentHp =[NSNumber numberWithInt:100];
        _MaxMp =[NSNumber numberWithInt:50];
        _CurrentMp =[NSNumber numberWithInt:50];
        _Agillity = [NSNumber numberWithInt:3];
        _isUser = NO;
        _AttackPower = [NSNumber numberWithInt:5];
        _Port = [UIImage imageNamed:@"NMESAMS"];
    }
    return self;
}

@end
