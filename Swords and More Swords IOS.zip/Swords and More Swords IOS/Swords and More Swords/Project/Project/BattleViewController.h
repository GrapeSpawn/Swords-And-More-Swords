//
//  BattleViewController.h
//  Project
//
//  Created by sebastion andrus on 11/8/12.
//  Copyright (c) 2012 sebastion andrus. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PlayerData.h"
#import "Abilitees.h"

@class BattleViewController;

@protocol BattleViewControllerDelegate
- (void)BattleViewControllerDidFinish:(BattleViewController *)controller;
@end
@interface BattleViewController : UIViewController <UITableViewDataSource, UITableViewDelegate, UIPopoverControllerDelegate>

@property (assign) bool *EndGame;

@property (weak, nonatomic) IBOutlet UIImageView *MainPlayerPort;
@property (weak, nonatomic) IBOutlet UIImageView *PartyOnePort;
@property (weak, nonatomic) IBOutlet UIImageView *PartyTwoPort;

@property (weak, nonatomic) IBOutlet UIImageView *FirstEnamyPort;
@property (weak, nonatomic) IBOutlet UIImageView *ThirdEnamyPort;
@property (weak, nonatomic) IBOutlet UIImageView *SecondEnemyPort;
@property (weak, nonatomic) IBOutlet UIImageView *FourthEnemyPort;
@property (weak, nonatomic) IBOutlet UIImageView *FithEnemyPort;
@property (weak, nonatomic) IBOutlet UIImageView *SixthEnemyPort;

@property (strong, nonatomic) NSMutableArray *Users;
@property (strong, nonatomic) NSMutableArray *Mobs;

@property (strong, nonatomic) id <BattleViewControllerDelegate> delegate;

@property (weak, nonatomic) IBOutlet UITextView *battleText;

@property (weak, nonatomic) IBOutlet UILabel *HP;
@property (weak, nonatomic) IBOutlet UILabel *MPLabel;
@property (weak, nonatomic) IBOutlet UILabel *MP;

@property (weak, nonatomic) IBOutlet UIButton *attckbuttn;
@property (weak, nonatomic) IBOutlet UIButton *skllButten;
@property (weak, nonatomic) IBOutlet UIButton *itemButten;
@property (weak, nonatomic) IBOutlet UITableView *table;
@property (weak, nonatomic) IBOutlet UILabel *whoseTurn;
@property (weak, nonatomic) IBOutlet UIButton *proceedButten;

@property (strong,nonatomic) NSString *PartTwoPort;
@property (strong,nonatomic) NSString *ParyOnePort;

- (IBAction)Proceed:(id)sender;

- (IBAction)Attack:(id)sender;

- (IBAction)Skill:(id)sender;

- (IBAction)Item:(id)sender;

@end
