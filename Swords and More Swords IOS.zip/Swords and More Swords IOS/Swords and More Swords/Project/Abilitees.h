//
//  Abilitees.h
//  Project
//
//  Created by sebastion andrus on 12/3/12.
//  Copyright (c) 2012 sebastion andrus. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PlayerData.h"

@interface Abilitees : NSObject

@property (strong, nonatomic) NSString *Name;
@property (strong, nonatomic) NSNumber *CountCost;
@property (assign) bool *Friendly;

-(NSString*) EffectAttker:(PlayerData *)Attker Deffender:(PlayerData *)Deffnd;
@end
