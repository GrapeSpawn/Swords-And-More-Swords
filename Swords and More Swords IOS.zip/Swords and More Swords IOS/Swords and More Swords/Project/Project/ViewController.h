//
//  ViewController.h
//  Project
//
//  Created by sebastion andrus on 11/8/12.
//  Copyright (c) 2012 sebastion andrus. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BattleViewController.h"
#import "PlayerData.h"
@class ViewController;
@protocol CombatViewControllerDelegate
- (void)ViewControllerDidFinish:(ViewController *)controller;
@end
@interface ViewController : UIViewController <BattleViewControllerDelegate>
@property (weak, nonatomic) IBOutlet UILabel *MainLbl;
@property (weak, nonatomic) IBOutlet UILabel *uGain;
@property (weak, nonatomic) IBOutlet UIButton *battleStart;
@property (weak, nonatomic) IBOutlet UITextView *Results;
@property (weak, nonatomic) IBOutlet UIButton *Done;
- (IBAction)Leave:(id)sender;
@property (weak, nonatomic) id <CombatViewControllerDelegate> delegate;
@property (strong, nonatomic) NSMutableArray *usersData;
@property (strong, nonatomic) NSMutableArray *MobData;

@property (strong, nonatomic) UIPopoverController *BattlePopOver;
@end
