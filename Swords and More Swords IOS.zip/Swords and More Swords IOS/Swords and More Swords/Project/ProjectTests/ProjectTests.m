//
//  ProjectTests.m
//  ProjectTests
//
//  Created by sebastion andrus on 11/8/12.
//  Copyright (c) 2012 sebastion andrus. All rights reserved.
//

#import "ProjectTests.h"

@implementation ProjectTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in ProjectTests");
}

@end
