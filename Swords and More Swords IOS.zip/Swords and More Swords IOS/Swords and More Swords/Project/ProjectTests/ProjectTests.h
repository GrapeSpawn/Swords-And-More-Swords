//
//  ProjectTests.h
//  ProjectTests
//
//  Created by sebastion andrus on 11/8/12.
//  Copyright (c) 2012 sebastion andrus. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface ProjectTests : SenTestCase

@end
