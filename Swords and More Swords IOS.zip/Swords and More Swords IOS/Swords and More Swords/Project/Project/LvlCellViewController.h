//
//  LvlCellViewController.h
//  Swords and More Swords
//
//  Created by sebastion andrus on 3/23/13.
//  Copyright (c) 2013 3400 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LvlCellViewController : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *StatValue;
@property (weak, nonatomic) IBOutlet UILabel *StatName;

@end
