//
//  Fire.h
//  Project
//
//  Created by sebastion andrus on 12/6/12.
//  Copyright (c) 2012 sebastion andrus. All rights reserved.
//

#import "Skills.h"

@interface Fire : Skills  <NSCoding>

@end
