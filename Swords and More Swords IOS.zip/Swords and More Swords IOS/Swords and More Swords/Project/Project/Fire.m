//
//  Fire.m
//  Project
//
//  Created by sebastion andrus on 12/6/12.
//  Copyright (c) 2012 sebastion andrus. All rights reserved.
//

#import "Fire.h"

@implementation Fire

-(NSString*) EffectAttker:(PlayerData *)Attker Deffender:(PlayerData *)Deffnd{
    NSLog(@"%@",Deffnd.CurrentHp);
    NSString *rtn;
    
    if(Attker.CurrentMp.intValue > self.CountCost.intValue){
        int hit = rand()%10+Attker.Intelligance.intValue;
        Deffnd.CurrentHp = [NSNumber numberWithInt:Deffnd.CurrentHp.intValue - hit];
        Attker.CurrentMp = [NSNumber numberWithInt:(Attker.CurrentMp.intValue - self.CountCost.intValue)];
        rtn = [[NSString alloc] initWithFormat:@"You did %i fire damage", hit];
        NSLog(@"%@",Deffnd.CurrentHp);
    }
    else{
        return @"Your spell fizzled, not enough Mp";
    }
    return rtn;
}
- (id)init {
    self = [super init];
    if (self) {
        self.Name = @"Fire";
        self.CountCost = [[NSNumber alloc] initWithInt:12];
        self.Friendly = NO;
    }
    return self;
}
- (void) encodeWithCoder:(NSCoder *)aCoder{
    [aCoder encodeObject:self.Name forKey:@"Name"];
    [aCoder encodeObject:self.CountCost forKey:@"Cost"];
    [aCoder encodeBool:self.Friendly forKey:@"Friendly"];
}
- (id)initWithCoder:(NSCoder *)aDecoder{
    self = [super init];
    
    if(self){
        self.Name = [aDecoder decodeObjectForKey:@"Name"];
        self.CountCost = [aDecoder decodeObjectForKey:@"Cost"];
        self.Friendly = [aDecoder decodeBoolForKey:@"Friendly"];
    }
    return self;
}
@end
