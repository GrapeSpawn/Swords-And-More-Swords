//
//  ViewController.m
//  Project
//
//  Created by sebastion andrus on 11/8/12.
//  Copyright (c) 2012 sebastion andrus. All rights reserved.
//

#import "ViewController.h"
#import "PLayerLoad.h"


@interface ViewController (){
    PlayerData *Defualts;
    PlayerData *userData;
}

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
	// Do any additional setup after loading the view, typically from a nib.
    if (self.usersData != NULL && self.MobData != NULL) {
        //Check for user and mobs, else make some
    }
    else
    {
        if (self.usersData == NULL) {
            self.usersData = [PLayerLoad Load];
        }
        if (self.MobData == NULL){
            self.MobData = [[NSMutableArray alloc] initWithCapacity:1];
            Defualts = [[PlayerData alloc] initWithLvl:1];
            Defualts.Name = @"defualt";
            Defualts.isUser = NO;
            [self.MobData addObject:Defualts];
        }
    }
    /*
    self.uGain.hidden = YES;
    self.battleStart.hidden =NO;
    self.Done.hidden = YES;
    self.Results.text = @"THE BATLE IS OVER!";
    self.Results.hidden = YES;
    self.MainLbl.hidden = NO;
     */
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)HealthReset{
    PlayerData *temp;
    for(int i = 0; i < self.usersData.count; i++){
        temp = self.usersData[i];
        temp.CurrentHp = [NSNumber numberWithInt:[temp.MaxHp unsignedIntegerValue]];
        temp.CurrentMp = [NSNumber numberWithInt:[temp.MaxMp unsignedIntegerValue]];
        temp.isDead = NO;
    }
    for(int i =0; i < self.MobData.count; i++){
        temp = self.MobData[i];
        temp.CurrentHp = [NSNumber numberWithInt:[temp.MaxHp unsignedIntegerValue]];
        temp.isDead = NO;
    }
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([[segue identifier] isEqualToString:@"Start"]) {

        //NSLog(@"%@",((PlayerData *)[MobData objectAtIndex:0]).Name);
        [self HealthReset];
        [[segue destinationViewController] setUsers:self.usersData];
        [[segue destinationViewController] setMobs:self.MobData];
        [[segue destinationViewController] setDelegate:self];
        [[segue destinationViewController] setEndGame:NO];
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
            UIPopoverController *popoverController = [(UIStoryboardPopoverSegue *)segue popoverController];
            self.BattlePopOver = popoverController;
            popoverController.delegate = self;
        }
    }
}


- (void)popoverControllerDidDismissPopover:(UIPopoverController *)popoverController
{
    self.BattlePopOver = nil;
}

- (IBAction)togglePopover:(id)sender
{
    if (self.BattlePopOver) {
        [self.BattlePopOver dismissPopoverAnimated:YES];
        self.BattlePopOver = nil;
    } else {
        [self performSegueWithIdentifier:@"showAlternate" sender:sender];
    }
}
- (void)BattleViewControllerDidFinish:(BattleViewController *)controller
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        [self dismissViewControllerAnimated:YES completion:nil];
    } else {
        [self.BattlePopOver dismissPopoverAnimated:YES];
        self.BattlePopOver = nil;
    }
    self.uGain.hidden = NO;
    self.battleStart.hidden =YES;
    self.Done.hidden = NO;
    self.Results.text = @"THE BATLE IS OVER!";
    self.Results.hidden = NO;
    self.MainLbl.hidden = YES;
    
}
- (IBAction)Leave:(id)sender {
    [self.delegate ViewControllerDidFinish:self];
}
@end
