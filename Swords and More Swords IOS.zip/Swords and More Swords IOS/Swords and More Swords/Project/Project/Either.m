//
//  Either.m
//  Project
//
//  Created by sebastion andrus on 12/6/12.
//  Copyright (c) 2012 sebastion andrus. All rights reserved.
//

#import "Either.h"

@implementation Either

-(NSString*) EffectAttker:(PlayerData *)Attker Deffender:(PlayerData *)Deffnd{
    //NSLog(@"%d",self.Count.intValue);
    if((self.CountCost.intValue > 0)){
        Deffnd.CurrentMp =[NSNumber numberWithInteger:([Deffnd.CurrentMp unsignedIntegerValue] + 15)];
        if ([Deffnd.CurrentMp unsignedIntegerValue] > [Deffnd.MaxMp unsignedIntegerValue]) {
            Deffnd.CurrentMp =[NSNumber numberWithInteger:[Deffnd.MaxMp unsignedIntegerValue]];
        }
        self.CountCost = [NSNumber numberWithInt:self.CountCost.intValue-1];
        return [NSString stringWithFormat:@"The either restored 15 Mp to %@", Deffnd.Name];
    }
    return @"Your are out of eithers";
}

- (id)init {
    self = [super init];
    if (self) {
        self.Name = @"Either";
        self.Friendly = YES;
    }
    return self;
}

- (void) encodeWithCoder:(NSCoder *)aCoder{
    [aCoder encodeObject:self.Name forKey:@"Name"];
    [aCoder encodeObject:self.CountCost forKey:@"Cost"];
    [aCoder encodeBool:self.Friendly forKey:@"Friendly"];
}
- (id)initWithCoder:(NSCoder *)aDecoder{
    self = [super init];
    
    if(self){
        self.Name = [aDecoder decodeObjectForKey:@"Name"];
        self.CountCost = [aDecoder decodeObjectForKey:@"Cost"];
        self.Friendly = [aDecoder decodeBoolForKey:@"Friendly"];
    }
    return self;
}

@end
