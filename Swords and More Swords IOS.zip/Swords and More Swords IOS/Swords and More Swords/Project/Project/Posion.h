//
//  Posion.h
//  Project
//
//  Created by sebastion andrus on 12/20/12.
//  Copyright (c) 2012 sebastion andrus. All rights reserved.
//

#import "Skills.h"

@interface Posion : Skills <NSCoding>

@end
