//
//  Potion.m
//  Project
//
//  Created by sebastion andrus on 12/3/12.
//  Copyright (c) 2012 sebastion andrus. All rights reserved.
//

#import "Potion.h"

@implementation Potion

-(NSString*) EffectAttker:(PlayerData *)Attker Deffender:(PlayerData *)Deffnd{
    //NSLog(@"%d",self.Count.intValue);
    if((self.CountCost.intValue > 0)){
        Deffnd.CurrentHp =[NSNumber numberWithInteger:([Deffnd.CurrentHp unsignedIntegerValue] + 25)];
        if ([Deffnd.CurrentHp unsignedIntegerValue] > [Deffnd.MaxHp unsignedIntegerValue]) {
            Deffnd.CurrentHp =[NSNumber numberWithInteger:[Deffnd.MaxHp unsignedIntegerValue]];
        }
        self.CountCost = [NSNumber numberWithInt:self.CountCost.intValue-1];
        return [NSString stringWithFormat:@"The potion restored 25 Hp to %@", Deffnd.Name];
    }
   return @"You are out of Potions";
}

- (id)init {
    self = [super init];
    if (self) {
        self.Name = @"Potion";
        self.Friendly = YES;
    }
    return self;
}

- (void) encodeWithCoder:(NSCoder *)aCoder{
    [aCoder encodeObject:self.Name forKey:@"Name"];
    [aCoder encodeObject:self.CountCost forKey:@"Cost"];
    [aCoder encodeBool:self.Friendly forKey:@"Friendly"];
}
- (id)initWithCoder:(NSCoder *)aDecoder{
    self = [super init];
    
    if(self){
        self.Name = [aDecoder decodeObjectForKey:@"Name"];
        self.CountCost = [aDecoder decodeObjectForKey:@"Cost"];
        self.Friendly = [aDecoder decodeBoolForKey:@"Friendly"];
    }
    return self;
}

@end
