//
//  Skills.h
//  Project
//
//  Created by sebastion andrus on 12/6/12.
//  Copyright (c) 2012 sebastion andrus. All rights reserved.
//

#import "Abilitees.h"

@interface Skills : Abilitees

@end
