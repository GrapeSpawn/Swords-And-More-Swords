//
//  LVLUPViewController.h
//  Swords and More Swords
//
//  Created by sebastion andrus on 3/23/13.
//  Copyright (c) 2013 3400 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PlayerData.h"

@interface LVLUPViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UILabel *StatPoints;
@property (weak, nonatomic) IBOutlet UITableView *Table;

@property (strong, nonatomic) PlayerData *player;

@end
